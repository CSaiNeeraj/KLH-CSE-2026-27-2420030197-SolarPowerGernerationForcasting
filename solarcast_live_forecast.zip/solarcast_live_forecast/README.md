# SolarCast Live Weather-Based Solar Forecast

## Run in VS Code
1. Download and extract `solarcast_live_forecast.zip`.
2. Open VS Code → **File → Open Folder** → choose the extracted `solarcast_live_forecast` folder.
3. Open `index.html`.
4. Run with the **Live Server** extension, or simply double-click `index.html` in File Explorer to open it in Chrome.
5. Keep your internet connection on. The site calls the public Open-Meteo forecast API to get weather and solar radiation data.

## Features
- Live hourly weather forecast for a selected latitude/longitude
- Seven-day energy estimate table
- Adjustable installed capacity and system efficiency
- Hourly chart and CSV export
- Default coordinates are for Hyderabad, India

## Formula and limitations
The site estimates hourly AC power as:
`power_kW = capacity_kW × (shortwave_radiation_W_m2 / 1000) × system_efficiency × temperature_factor`
Hourly energy is approximated by summing hourly power values. Daily solar radiation totals from the API are given in MJ/m² and converted to kWh/m² for display.

This is a working live weather-based estimate, not a trained machine-learning model and not a substitute for a calibrated PV simulation. For a true ML project, train and evaluate a model on historical solar plant generation paired with weather features, then integrate that model.
Weather data source: https://open-meteo.com/
