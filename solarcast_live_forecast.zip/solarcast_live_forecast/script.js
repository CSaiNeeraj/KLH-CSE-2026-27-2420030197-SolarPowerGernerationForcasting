(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const API = 'https://api.open-meteo.com/v1/forecast';
  let forecastData = null;
  let chartPoints = [];
  let toastTimer;

  function toast(message) {
    const el = $('toast');
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
  }

  function setStatus(state, message) {
    const el = document.querySelector('.status');
    el.className = 'status ' + state;
    $('statusText').textContent = message;
  }

  function updateSliderLabels() {
    $('capacityValue').textContent = $('capacity').value;
    $('efficiencyValue').textContent = $('efficiency').value;
  }

  function getSettings() {
    return {
      name: $('locationName').value.trim() || 'Selected location',
      lat: Number($('latitude').value),
      lon: Number($('longitude').value),
      capacity: Number($('capacity').value),
      efficiency: Number($('efficiency').value) / 100
    };
  }

  function validSettings(s) {
    return Number.isFinite(s.lat) && s.lat >= -90 && s.lat <= 90 &&
      Number.isFinite(s.lon) && s.lon >= -180 && s.lon <= 180 &&
      Number.isFinite(s.capacity) && s.capacity > 0 &&
      Number.isFinite(s.efficiency) && s.efficiency > 0 && s.efficiency <= 1;
  }

  async function loadForecast() {
    const s = getSettings();
    if (!validSettings(s)) {
      toast('Please enter valid latitude and longitude values.');
      return;
    }

    setStatus('', 'Loading live weather…');
    $('refreshBtn').disabled = true;
    $('refreshBtn').textContent = '↻ Loading…';
    $('dailyRows').innerHTML = '<tr><td colspan="5" class="empty">Fetching forecast data…</td></tr>';

    const params = new URLSearchParams({
      latitude: String(s.lat),
      longitude: String(s.lon),
      hourly: 'temperature_2m,cloud_cover,shortwave_radiation',
      daily: 'temperature_2m_max,shortwave_radiation_sum,weather_code',
      forecast_days: '7',
      timezone: 'auto'
    });

    try {
      const response = await fetch(`${API}?${params.toString()}`);
      if (!response.ok) throw new Error(`Weather service returned HTTP ${response.status}`);
      const data = await response.json();
      if (data.error) throw new Error(data.reason || 'Weather service could not return data.');
      if (!data.hourly || !data.hourly.time || !data.hourly.shortwave_radiation) {
        throw new Error('The weather service did not return the required solar radiation data.');
      }
      forecastData = data;
      renderForecast(s);
      setStatus('ok', 'LIVE WEATHER DATA CONNECTED');
      $('updatedAt').textContent = `Updated ${new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})} · ${data.timezone || 'Local time'} · Source: Open-Meteo`;
    } catch (err) {
      console.error(err);
      setStatus('error', 'WEATHER DATA UNAVAILABLE');
      $('dailyRows').innerHTML = `<tr><td colspan="5" class="empty">Could not load weather data. Check your internet connection and try again. (${escapeHTML(err.message)})</td></tr>`;
      $('chartMessage').style.display = 'grid';
      $('chartMessage').textContent = 'Weather data unavailable';
      toast('Could not load live weather. Check internet access and press Refresh.');
    } finally {
      $('refreshBtn').disabled = false;
      $('refreshBtn').textContent = '↻ Refresh weather';
    }
  }

  function estimatePower(radiationWm2, tempC, settings) {
    // Simple performance estimate: irradiance scaled to kW/m², capacity,
    // user-selected system efficiency and a small temperature derating.
    const tempFactor = Math.max(0.82, 1 - Math.max(0, tempC - 25) * 0.004);
    return Math.max(0, settings.capacity * (Math.max(0, radiationWm2) / 1000) * settings.efficiency * tempFactor);
  }

  function renderForecast(settings) {
    const h = forecastData.hourly;
    const d = forecastData.daily;
    const today = new Date().toLocaleDateString();
    const todayIndex = h.time.findIndex(t => new Date(t).toLocaleDateString() === today);
    const start = todayIndex >= 0 ? todayIndex : 0;
    const todayDate = h.time[start].slice(0, 10);
    const indices = h.time.map((t, i) => ({t, i})).filter(x => x.t.slice(0,10) === todayDate);
    chartPoints = indices.map(({t, i}) => ({
      time: t.slice(11,16),
      temp: Number(h.temperature_2m?.[i] ?? 25),
      radiation: Number(h.shortwave_radiation?.[i] ?? 0),
      cloud: Number(h.cloud_cover?.[i] ?? 0),
      power: estimatePower(Number(h.shortwave_radiation?.[i] ?? 0), Number(h.temperature_2m?.[i] ?? 25), settings)
    }));

    const energy = chartPoints.reduce((sum, p) => sum + p.power, 0);
    const peak = Math.max(0, ...chartPoints.map(p => p.power));
    const radiation = chartPoints.reduce((sum, p) => sum + p.radiation, 0) / 1000;
    $('dailyEnergy').innerHTML = `${energy.toFixed(2)} <small>kWh</small>`;
    $('peakPower').innerHTML = `${peak.toFixed(2)} <small>kW</small>`;
    $('radiation').innerHTML = `${radiation.toFixed(2)} <small>kWh/m²</small>`;
    $('displayLocation').textContent = settings.name;
    $('forecastDate').textContent = new Date(todayDate + 'T12:00:00').toLocaleDateString(undefined, {weekday:'short', month:'short', day:'numeric'});
    $('chartMessage').style.display = 'none';
    drawChart();
    renderDailyTable(settings);
  }

  function weatherLabel(code) {
    if (code === 0) return 'Clear';
    if ([1,2].includes(code)) return 'Partly cloudy';
    if (code === 3) return 'Overcast';
    if ([45,48].includes(code)) return 'Fog';
    if (code >= 51 && code <= 67) return 'Drizzle / rain';
    if (code >= 71 && code <= 77) return 'Snow';
    if (code >= 80 && code <= 82) return 'Rain showers';
    if (code >= 95) return 'Thunderstorm';
    return 'Mixed';
  }

  function renderDailyTable(settings) {
    const d = forecastData.daily;
    const h = forecastData.hourly;
    const rows = d.time.map((date, dayIndex) => {
      const hourlyIndices = h.time.map((time, i) => time.slice(0,10) === date ? i : -1).filter(i => i >= 0);
      const energy = hourlyIndices.reduce((sum, i) => sum + estimatePower(Number(h.shortwave_radiation?.[i] ?? 0), Number(h.temperature_2m?.[i] ?? 25), settings), 0);
      const rad = Number(d.shortwave_radiation_sum?.[dayIndex] ?? 0);
      const radiationKwh = rad / 3.6; // MJ/m² to kWh/m²
      const dateLabel = new Date(date + 'T12:00:00').toLocaleDateString(undefined, {weekday:'short', month:'short', day:'numeric'});
      const maxTemp = d.temperature_2m_max?.[dayIndex];
      return `<tr><td>${dateLabel}</td><td><span class="weather-tag">${weatherLabel(Number(d.weather_code?.[dayIndex] ?? -1))}</span></td><td>${Number.isFinite(maxTemp) ? `${Math.round(maxTemp)}°C` : '—'}</td><td>${radiationKwh.toFixed(2)} kWh/m²</td><td><strong>${energy.toFixed(2)} kWh</strong></td></tr>`;
    });
    $('dailyRows').innerHTML = rows.join('');
  }

  function drawChart() {
    const canvas = $('chart');
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(280, rect.width || 600);
    const height = 270;
    const dpr = Math.max(1, window.devicePixelRatio || 1);
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    const ctx = canvas.getContext('2d');
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);
    if (!chartPoints.length) {
      $('chartMessage').style.display = 'grid';
      return;
    }
    const left = 43, right = 12, top = 16, bottom = 38;
    const pw = width - left - right, ph = height - top - bottom;
    const max = Math.max(1, Math.ceil(Math.max(...chartPoints.map(p => p.power)) * 1.15));
    ctx.font = '11px Arial'; ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
    for (let i = 0; i <= 4; i++) {
      const y = top + ph * i / 4;
      ctx.strokeStyle = '#e9eee9'; ctx.beginPath(); ctx.moveTo(left,y); ctx.lineTo(width-right,y); ctx.stroke();
      ctx.fillStyle = '#89958c'; ctx.fillText((max * (1-i/4)).toFixed(1), left-8, y);
    }
    const points = chartPoints.map((p, i) => ({x:left + pw * i / Math.max(1, chartPoints.length-1), y:top + ph * (1-p.power/max), p}));
    const grad = ctx.createLinearGradient(0, top, 0, top+ph);
    grad.addColorStop(0,'rgba(47,128,85,.24)'); grad.addColorStop(1,'rgba(47,128,85,.01)');
    ctx.beginPath(); ctx.moveTo(points[0].x, top+ph); points.forEach(p=>ctx.lineTo(p.x,p.y)); ctx.lineTo(points[points.length-1].x,top+ph); ctx.closePath(); ctx.fillStyle=grad; ctx.fill();
    ctx.beginPath(); points.forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y)); ctx.strokeStyle='#2f8055'; ctx.lineWidth=2.5; ctx.lineJoin='round'; ctx.stroke();
    points.forEach((p,i)=>{if(i%3===0){ctx.beginPath();ctx.arc(p.x,p.y,3,0,Math.PI*2);ctx.fillStyle='#2f8055';ctx.fill();}});
    ctx.fillStyle='#89958c';ctx.textAlign='center';ctx.textBaseline='top';
    points.forEach((p,i)=>{if(i%3===0 || i===points.length-1)ctx.fillText(p.p.time,p.x,height-bottom+11);});
  }

  function exportCSV() {
    if (!forecastData) { toast('Load weather data before exporting.'); return; }
    const settings = getSettings();
    const rows = [
      ['SolarCast live weather-based solar estimate'],
      ['Location', settings.name], ['Latitude', settings.lat], ['Longitude', settings.lon],
      ['Installed capacity (kW)', settings.capacity], ['System efficiency (%)', Math.round(settings.efficiency*100)],
      ['Data source', 'Open-Meteo forecast API'], [],
      ['Date', 'Time', 'Temperature (C)', 'Cloud cover (%)', 'Solar radiation (W/m2)', 'Estimated output (kW)'],
      ...forecastData.hourly.time.map((time, i) => [
        time.slice(0,10), time.slice(11,16), forecastData.hourly.temperature_2m?.[i] ?? '',
        forecastData.hourly.cloud_cover?.[i] ?? '', forecastData.hourly.shortwave_radiation?.[i] ?? '',
        estimatePower(Number(forecastData.hourly.shortwave_radiation?.[i] ?? 0), Number(forecastData.hourly.temperature_2m?.[i] ?? 25), settings).toFixed(3)
      ])
    ];
    const csv = rows.map(row => row.map(v => `"${String(v ?? '').replace(/"/g,'""')}"`).join(',')).join('\r\n');
    const blob = new Blob(['\uFEFF' + csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'solarcast_weather_forecast.csv';
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1000);
    toast('CSV forecast downloaded.');
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  $('settingsForm').addEventListener('submit', e => { e.preventDefault(); loadForecast(); });
  $('refreshBtn').addEventListener('click', loadForecast);
  $('csvBtn').addEventListener('click', exportCSV);
  $('capacity').addEventListener('input', updateSliderLabels);
  $('efficiency').addEventListener('input', updateSliderLabels);
  $('useHyderabad').addEventListener('click', () => {
    $('locationName').value = 'Hyderabad'; $('latitude').value = '17.3850'; $('longitude').value = '78.4867';
    $('capacity').value = '5'; $('efficiency').value = '82'; updateSliderLabels(); loadForecast();
  });
  let resizeTimer;
  window.addEventListener('resize', () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(drawChart,120); });
  updateSliderLabels();
  loadForecast();
})();